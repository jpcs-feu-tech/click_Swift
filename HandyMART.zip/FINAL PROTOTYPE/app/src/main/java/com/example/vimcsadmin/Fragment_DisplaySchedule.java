package com.example.vimcsadmin;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class Fragment_DisplaySchedule extends Fragment {
    String purpose, date, time, dateAdded,queue;
    TextView txtStatus, txtTask, txtTime,txtQueue, txtRegion, txtOffice;
    Button btnBack;
    int regionId, officeId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        SharedPreferences sp = getActivity().getApplication().getSharedPreferences("schedule", Context.MODE_PRIVATE);
        if(sp.contains("purpose")) {
            purpose = sp.getString("purpose",null);
            date = sp.getString("date", null);
            time = sp.getString("time", null);
            dateAdded = sp.getString("dateAdded",null);
            queue = sp.getString("queue",null);
            regionId = sp.getInt("regionId", 0);
            officeId = sp.getInt("officeId",0);
        }
        return inflater.inflate(R.layout.fragment_display_schedule, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        txtStatus = view.findViewById(R.id.txtDate);
        txtTask = view.findViewById(R.id.txtPurpose);
        txtTime = view.findViewById(R.id.txtTime);
        btnBack = view.findViewById(R.id.btnBack);
        txtQueue = view.findViewById(R.id.txtQueue);
        txtRegion = view.findViewById(R.id.txtRegion);
        txtOffice = view.findViewById(R.id.txtOffice);

        txtTask.setText(purpose);
        txtStatus.setText(date);
        txtTime.setText(time);
        txtQueue.setText(queue);

        if(regionId == 1){
            txtRegion.setText("RHPU NCR");
        }else if(regionId == 2){
            txtRegion.setText("RHPU 1");
        }else if(regionId == 3){
            txtRegion.setText("RHPU 2");
        }else if(regionId == 4){
            txtRegion.setText("RHPU 3");
        }else if(regionId == 5){
            txtRegion.setText("RHPU 4A");
        }else if(regionId == 6){
            txtRegion.setText("RHPU 4B");
        }else if(regionId == 7){
            txtRegion.setText("RHPU 5");
        }else if(regionId == 8){
            txtRegion.setText("RHPU 6");
        }else if(regionId == 9){
            txtRegion.setText("RHPU 7");
        }else if(regionId == 10){
            txtRegion.setText("RHPU 8");
        }else if(regionId == 11){
            txtRegion.setText("RHPU 9");
        }else if(regionId == 12){
            txtRegion.setText("RHPU 10");
        }else if(regionId == 13){
            txtRegion.setText("RHPU 11");
        }else if(regionId == 14){
            txtRegion.setText("RHPU 12");
        }else if(regionId == 15){
            txtRegion.setText("RHPU 13");
        }else if(regionId == 16){
            txtRegion.setText("RHPU COR");
        }else if(regionId == 17){
            txtRegion.setText("RHPU ARMM");
        }

        if(officeId == 1){
            txtOffice.setText("Northern District");
        }else if(officeId == 2){
            txtOffice.setText("Eastern District");
        }else if(officeId == 3){
            txtOffice.setText("Southern District - Muntinlupa");
        }else if(officeId == 4){
            txtOffice.setText("QCHP District - Novaliches");
        }else if(officeId == 5){
            txtOffice.setText("QCHP District - La loma");
        }else if(officeId == 6){
            txtOffice.setText("Manila District");
        }else if(officeId == 7){
            txtOffice.setText("PHPT ILOCOS NORTE");
        }else if(officeId == 8){
            txtOffice.setText("PHPT ILOCOS SUR");
        }else if(officeId == 9){
            txtOffice.setText("PHPT LA UNION");
        }else if(officeId == 10){
            txtOffice.setText("PHPT PANGASINAN");
        }else if(officeId == 11){
            txtOffice.setText("PHPT ISABELA");
        }else if(officeId == 12){
            txtOffice.setText("PHPT CAGAYAN");
        }else if(officeId == 13){
            txtOffice.setText("PHPT QUIRINO");
        }else if(officeId == 14){
            txtOffice.setText("PHPT NUEVA VISCAYA");
        }else if(officeId == 15){
            txtOffice.setText("PHPT BULACAN");
        }else if(officeId == 16){
            txtOffice.setText("PHPT TARLAC");
        }else if(officeId == 17){
            txtOffice.setText("PHPT BATAAN");
        }else if(officeId == 18){
            txtOffice.setText("PHPT NUEVA ECIJA");
        }else if(officeId == 19){
            txtOffice.setText("PHPT PAMPANGA");
        }else if(officeId == 20){
            txtOffice.setText("PHPT ZAMBALES");
        }else if(officeId == 21){
            txtOffice.setText("PHPT LAGUNA");
        }else if(officeId == 22){
            txtOffice.setText("PHPT BATANGAS");
        }else if(officeId == 23){
            txtOffice.setText("PHPT CAVITE");
        }else if(officeId == 24){
            txtOffice.setText("PHPT RIZAL");
        }else if(officeId == 25){
            txtOffice.setText("PHPT QUEZON");
        }else if(officeId == 26){
            txtOffice.setText("PHPT MINDORO OCC");
        }else if(officeId == 27){
            txtOffice.setText("PHPT PALAWAN");
        }else if(officeId == 28){
            txtOffice.setText("PHPT MINDORO OR");
        }else if(officeId == 29){
            txtOffice.setText("PHPT MARINDUQUE");
        }else if(officeId == 30){
            txtOffice.setText("PHPT ROMBLON");
        }else if(officeId == 31){
            txtOffice.setText("PHPT CAM NORTE");
        }else if(officeId == 32){
            txtOffice.setText("PHPT CAM SUR");
        }else if(officeId == 33){
            txtOffice.setText("PHPT ALBAY");
        }else if(officeId == 34){
            txtOffice.setText("PHPT SORSOGON");
        }else if(officeId == 35){
            txtOffice.setText("PHPT MASBATE");
        }else if(officeId == 36){
            txtOffice.setText("PHPT CATANDUANES");
        }else if(officeId == 37){
            txtOffice.setText("PHPT ILOILO");
        }else if(officeId == 38){
            txtOffice.setText("PHPT AKLAN");
        }else if(officeId == 39){
            txtOffice.setText("PHPT ANTIQUE");
        }else if(officeId == 40){
            txtOffice.setText("PHPT CAPIZ");
        }else if(officeId == 41){
            txtOffice.setText("PHPT GUIMARAS");
        }else if(officeId == 42){
            txtOffice.setText("PHPT NEGROS OCC");
        }else if(officeId == 43){
            txtOffice.setText("PHPT CEBU");
        }else if(officeId == 44){
            txtOffice.setText("PHPT BOHOL");
        }else if(officeId == 45){
            txtOffice.setText("PHPT NEGROS ORR");
        }else if(officeId == 46){
            txtOffice.setText("PHPT METRO CEBU");
        }else if(officeId == 47){
            txtOffice.setText("PHPT LEYTE NORTE");
        }else if(officeId == 48){
            txtOffice.setText("PHPT LEYTE SUR");
        }else if(officeId == 49){
            txtOffice.setText("PHPT WESTERN SAMAR");
        }else if(officeId == 50){
            txtOffice.setText("PHPT NORTHERN SAMAR");
        }else if(officeId == 51){
            txtOffice.setText("PHPT EASTERN SAMAR");
        }else if(officeId == 52){
            txtOffice.setText("PHPT ZAMB DELSUR");
        }else if(officeId == 53){
            txtOffice.setText("PHPT ZAMB NORTE");
        }else if(officeId == 54){
            txtOffice.setText("PHPT ZAMB SIBUGAY");
        }else if(officeId == 55){
            txtOffice.setText("PHPT CAGAYAN DE ORO");
        }else if(officeId == 56){
            txtOffice.setText("PHPT ILIGAN CITY");
        }else if(officeId == 57){
            txtOffice.setText("PHPT LANAO DEL NORTE");
        }else if(officeId == 58){
            txtOffice.setText("PHPT BUKIDNON");
        }else if(officeId == 59){
            txtOffice.setText("PHPT MISAMIS ORR");
        }else if(officeId == 60){
            txtOffice.setText("PHPT MISAMIS OCC");
        }else if(officeId == 61){
            txtOffice.setText("PHPT DAVAO DEL SUR");
        }else if(officeId == 62){
            txtOffice.setText("PHPT DAVAO ORIENTAL");
        }else if(officeId == 63){
            txtOffice.setText("PHPT DAVAO DEL NORTE");
        }else if(officeId == 64){
            txtOffice.setText("PHPT COMPOSTELLA VALLEY");
        }else if(officeId == 65){
            txtOffice.setText("PHPT GEN.SANTOS");
        }else if(officeId == 66){
            txtOffice.setText("PHPT SULTAN KUDARAT");
        }else if(officeId == 67){
            txtOffice.setText("PHPT SARANGANI");
        }else if(officeId == 68){
            txtOffice.setText("PHPT SOUTH COTABATO");
        }else if(officeId == 69){
            txtOffice.setText("PHPT NORTH COTABATO");
        }else if(officeId == 70){
            txtOffice.setText("PHPT AGUSAN DEL NORTE");
        }else if(officeId == 71){
            txtOffice.setText("PHPT AGUSAN DEL SUR");
        }else if(officeId == 72){
            txtOffice.setText("PHPT SURIGAO DEL NORTE");
        }else if(officeId == 73){
            txtOffice.setText("PHPT SURIGAO DEL SUR");
        }else if(officeId == 74){
            txtOffice.setText("PHPT ABRA");
        }else if(officeId == 75){
            txtOffice.setText("PHPT MT.PROVINCE");
        }else if(officeId == 76){
            txtOffice.setText("PHPT IFUGAO");
        }else if(officeId == 77){
            txtOffice.setText("PHPT KALINGA");
        }else if(officeId == 78){
            txtOffice.setText("PHPT BENGUET");
        }else if(officeId == 79){
            txtOffice.setText("PHPT LANAO DEL SUR");
        }else if(officeId == 80){
            txtOffice.setText("PHPT MAGUINDANAO");
        }else if(officeId == 81){
            txtOffice.setText("PHPT VASULTA");
        }


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new Fragment_ViewSchedule();
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction ft = fragmentManager.beginTransaction();
                ft.replace(R.id.screen_area,fragment);
                ft.commit();
            }
        });

    }
}
