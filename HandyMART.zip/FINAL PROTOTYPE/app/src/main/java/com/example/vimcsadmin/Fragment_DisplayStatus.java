package com.example.vimcsadmin;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class Fragment_DisplayStatus extends Fragment {
    String engNo, chasisNo, plateNo;
    int applicationStatus, correctionStatus, stampingStatus;
    TextView txtEngNo, txtChasisNo, txtPlateNo, txtApplicationStatus, txtCorrectionStatus, txtStampingStatus;
    Button btnBack;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        SharedPreferences sp = getActivity().getApplication().getSharedPreferences("status", Context.MODE_PRIVATE);
        if(sp.contains("plateNo")) {
            engNo = sp.getString("engNo",null);
            chasisNo = sp.getString("chassisNo", null);
            plateNo = sp.getString("plateNo", null);
            applicationStatus = sp.getInt("applicationStatus",0);
            correctionStatus = sp.getInt("correctionStatus",0);
            stampingStatus = sp.getInt("stampingStatus",0);
        }
        return inflater.inflate(R.layout.fragment_fragment__check_status_info, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        txtEngNo = view.findViewById(R.id.txtEngineNo);
        txtChasisNo = view.findViewById(R.id.txtChasisNo);
        txtPlateNo = view.findViewById(R.id.txtPlateNo);
        txtApplicationStatus = view.findViewById(R.id.txtApplicationStatus);
        txtStampingStatus = view.findViewById(R.id.txtStampingStatus);
        txtCorrectionStatus = view.findViewById(R.id.txtCorrectionStatus);
        btnBack = view.findViewById(R.id.btnBack);

        txtEngNo.setText(engNo);
        txtChasisNo.setText(chasisNo);
        txtPlateNo.setText(plateNo);

        if(applicationStatus == 1){
            txtApplicationStatus.setText("For Payment");
        }else if(applicationStatus == 2 || applicationStatus == 3){
            txtApplicationStatus.setText("For Inspection");
        }else if(applicationStatus == 4){
            txtApplicationStatus.setText("On Process");
        }else if(applicationStatus == 5){
            txtApplicationStatus.setText("Releasing");
        }else if(applicationStatus == 6){
            txtApplicationStatus.setText("Approved Clearance Application");
        }else if(applicationStatus == 7){
            txtApplicationStatus.setText("Declined Clearance Application");
        }else if(applicationStatus == 8){
            txtApplicationStatus.setText("Requesting Nationwide Alarm Application");
        }else if(applicationStatus == 9){
            txtApplicationStatus.setText("For Notary Submission");
        }else if(applicationStatus == 10){
            txtApplicationStatus.setText("For Document Submission");
        }else if(applicationStatus == 11 || applicationStatus == 12 || applicationStatus == 13
                || applicationStatus == 14 || applicationStatus == 15 || applicationStatus == 16){
            txtApplicationStatus.setText("Pending Approval for Nationwid Alarm Application");
        }else if(applicationStatus == 17){
            txtApplicationStatus.setText("Recieve Copy of Nationwide Alarm");
        }else if(applicationStatus == 18){
            txtApplicationStatus.setText("Declined Nationwide Alarm Application");
        }else if(applicationStatus == 19){
            txtApplicationStatus.setText("Requesting Lifting of Alarm in Application");
        }else if(applicationStatus == 20){
            txtApplicationStatus.setText("For Notary Submission");
        }else if(applicationStatus == 21){
            txtApplicationStatus.setText("For Document Submission");
        }else if(applicationStatus == 22 || applicationStatus == 23 || applicationStatus == 24
                || applicationStatus == 25){
            txtApplicationStatus.setText("Pending Approval for Lifting of Alarm Application");
        }

        if(correctionStatus == 1){
            txtCorrectionStatus.setText("Requesting for Correction of Entry/Deletion");
        }else if(correctionStatus == 2){
            txtCorrectionStatus.setText("For Notary Submission");
        }else if(correctionStatus == 3){
            txtCorrectionStatus.setText("For Document Submission");
        }else if(correctionStatus == 4){
            txtCorrectionStatus.setText("Pending Approval for Correction of Entry/Deletion Application");
        }else if(correctionStatus == 5){
            txtCorrectionStatus.setText("Approved Correction of Entry/Deletion Application");
        }else if(correctionStatus == 6){
            txtCorrectionStatus.setText("Declined Correction of Entry / Deletion Application");
        }

        if(stampingStatus == 1){
            txtStampingStatus.setText("Requesting Re-stamping Recorded MV");
        }else if(stampingStatus == 2){
            txtStampingStatus.setText("For Document Submission");
        }else if(stampingStatus == 3|| stampingStatus == 4|| stampingStatus == 5
                ||stampingStatus == 6 || stampingStatus == 7|| stampingStatus == 8){
            txtStampingStatus.setText("Pending Approval for Re-stamping Recorded MV Application");
        }else if(stampingStatus == 9){
            txtStampingStatus.setText("Receive Copy of Re-stamping Recorded MV");
        }else if(stampingStatus == 10){
            txtStampingStatus.setText("Declined Re-stamping Recorded MV Application");
        }else if(stampingStatus == 11){
            txtStampingStatus.setText("Requesting Re-stamping Natural Deterioration");
        }else if(stampingStatus == 12){
            txtStampingStatus.setText("For Document Submission");
        }else if(stampingStatus == 13||stampingStatus == 14||stampingStatus == 15||
                stampingStatus == 16||stampingStatus == 17||stampingStatus == 18){
            txtStampingStatus.setText("Pending Approval for Re-stamping Natural Deterioration Application");
        }else if(stampingStatus == 19){
            txtStampingStatus.setText("Receive Copy of Re-stamping Natural Deterioration");
        }else if(stampingStatus == 20){
            txtStampingStatus.setText("Declined Re-stamping Natural Deterioration Application");
        }




        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new Fragment_ViewStatus();
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction ft = fragmentManager.beginTransaction();
                ft.replace(R.id.screen_area,fragment);
                ft.commit();
            }
        });

    }
}
