package com.example.vimcsadmin;

public class Schedule {

    private int scheduleId;
    private int userId;
    private String purpose;
    private String date;
    private String time;
    private String dateAdded;
    private String queueNo;
    private int region;
    private int office;

    public Schedule(int scheduleId, int userId, String purpose, String date, String time, String dateAdded, String queueNo, int region, int office) {
        this.scheduleId = scheduleId;
        this.userId = userId;
        this.purpose = purpose;
        this.date = date;
        this.time = time;
        this.dateAdded = dateAdded;
        this.queueNo = queueNo;
        this.region = region;
        this.office = office;
    }

    public int getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(int scheduleId) {
        this.scheduleId = scheduleId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(String dateAdded) {
        this.dateAdded = dateAdded;
    }

    public String getQueueNo() {
        return queueNo;
    }

    public void setQueueNo(String queueNo) {
        this.queueNo = queueNo;
    }

    public int getRegion() {
        return region;
    }

    public void setRegion(int region) {
        this.region = region;
    }

    public int getOffice() {
        return office;
    }

    public void setOffice(int office) {
        this.office = office;
    }


}
