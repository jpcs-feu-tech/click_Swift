package com.example.vimcsadmin;

public class Links {
    public static final String ROOT_URL = "http://3.1.244.230/";
    //public static final String ROOT_URL = "http://192.168.32.167/ci/";
    public static final String LOGIN = ROOT_URL + "mobile/loginUSer";
    public static final String GET_RECORD = ROOT_URL + "mobile/getSchedule";
    public static final String GET_STATUS = ROOT_URL + "mobile/getStatus";
    public static final String REGISTER = ROOT_URL + "mobile/register";
    public static final String ADD_SCHEDULE = ROOT_URL + "mobile/addSchedule";
    public static final String DOWNLOAD_MOTOR_CLEARANCE = ROOT_URL + "assets/form/Clearance.pdf";
    public static final String DOWNLOAD_CORRECTION_OF_ENTRY_DELETION = ROOT_URL + "assets/form/Correction.pdf";
    public static final String DOWNLOAD_CERTIFICATE_OF_NON_RECOVERY = ROOT_URL + "assets/form/Nonrecovery.pdf";
    public static final String DOWNLOAD_NATION_WIDE_ALARM = ROOT_URL + "assets/form/Complaint.pdf";
    public static final String DOWNLOAD_LIFTING_OF_ALARM = ROOT_URL + "assets/form/Lifting.pdf";
    public static final String DOWNLOAD_RE_STAMPING = ROOT_URL + "assets/form/Restamping.pdf";
}
