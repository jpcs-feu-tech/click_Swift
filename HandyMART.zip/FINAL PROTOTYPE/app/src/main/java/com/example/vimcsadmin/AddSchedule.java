package com.example.vimcsadmin;


import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;


/**
 * A simple {@link Fragment} subclass.
 */
public class AddSchedule extends Fragment implements AdapterView.OnItemSelectedListener {

    private static final int CODE_POST_REQUEST = 1025;
    TextView txtDate, txtTime;
    Button btnChooseDate, btnChooseTime, btnAddSchedule, btnBack;
    TimePickerDialog timepicker;
    Spinner spnPurpose, spnTime, spnRegion, spnOffice;
    int currentHour, currentMinute;
    String time, formattedDate, purpose, timereserve, region, office;
    ProgressDialog progressDialog;
    int id,regionId,officeId;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        SharedPreferences sp = getActivity().getApplication().getSharedPreferences("user", MODE_PRIVATE);
        if(sp.contains("logStatus")) {
            id = sp.getInt("user_id", 0);
        }
        return inflater.inflate(R.layout.fragment_add_schedule, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        txtDate = view.findViewById(R.id.txtDate);
        //txtTime = view.findViewById(R.id.txtTime);
        btnChooseDate = view.findViewById(R.id.btnChooseDate);
       // btnChooseTime = view.findViewById(R.id.btnChooseTime);
        btnAddSchedule = view.findViewById(R.id.btnAddSchedule);
        spnPurpose = view.findViewById(R.id.spnPurpose);
        spnRegion = view.findViewById(R.id.spnRegion);
        spnTime = view.findViewById(R.id.spnTime);
        spnOffice = view.findViewById(R.id.spnOffice);
        btnBack = view.findViewById(R.id.btnBack);
        progressDialog = new ProgressDialog(getContext());

        Calendar cd = Calendar.getInstance();
        currentHour = cd.get(Calendar.HOUR_OF_DAY);
        currentMinute = cd.get(Calendar.MINUTE);
        time = String.valueOf(currentHour) + ":" + String.valueOf(currentMinute);
        //txtTime.setText(time);
        Toast.makeText(getContext().getApplicationContext(),currentHour+":"+currentMinute,Toast.LENGTH_SHORT).show();

        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df  = new SimpleDateFormat("yyyy-MM-dd");
        formattedDate = df.format(c);

        txtDate.setText(formattedDate);

        btnChooseDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });

        /*btnChooseTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              // DialogFragment timePickerFragment = new TimePickerFragment();
                timePickerFragment.show(getFragmentManager(),"time picker"); //
                timepicker = new TimePickerDialog(getContext(), new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        currentHour = hourOfDay;
                        currentMinute = minute;
                        time = String.valueOf(currentHour) + ":" + String.valueOf(currentMinute);
                        txtTime.setText(time);
                    }
                },currentHour,currentMinute,false);
                timepicker.show();
            }
        }); */

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new Fragment_ViewSchedule();
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction ft = fragmentManager.beginTransaction();
                ft.replace(R.id.screen_area,fragment);
                ft.commit();
            }
        });

        btnAddSchedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addSchedule();
            }
        });

        spnRegion.setOnItemSelectedListener(this);

    }

    private void addSchedule() {
        purpose = spnPurpose.getSelectedItem().toString();
        timereserve = spnTime.getSelectedItem().toString();
        office = spnOffice.getSelectedItem().toString();
        formattedDate = txtDate.getText().toString();

        if(office.equals("Northern District")){
            officeId = 1;
        }else if(office.equals("Eastern District")){
            officeId = 2;
        }else if(office.equals("Southern District - Muntinlupa")){
            officeId = 3;
        }else if(office.equals("QCHP District - Novaliches")){
            officeId = 4;
        }else if(office.equals("QCHP District - La loma")){
            officeId = 5;
        }else if(office.equals("Manila District")){
            officeId = 6;
        }else if(office.equals("PHPT ILOCOS NORTE")){
            officeId = 7;
        }else if(office.equals("PHPT ILOCOS SUR")){
            officeId = 8;
        }else if(office.equals("PHPT LA UNION")){
            officeId = 9;
        }else if(office.equals("PHPT PANGASINAN")){
            officeId = 10;
        }else if(office.equals("PHPT ISABELA")){
            officeId = 11;
        }else if(office.equals("PHPT CAGAYAN")){
            officeId = 12;
        }else if(office.equals("PHPT QUIRINO")){
            officeId = 13;
        }else if(office.equals("PHPT NUEVA VISCAYA")){
            officeId = 14;
        }else if(office.equals("PHPT BULACAN")){
            officeId = 15;
        }else if(office.equals("PHPT TARLAC")){
            officeId = 16;
        }else if(office.equals("PHPT BATAAN")){
            officeId = 17;
        }else if(office.equals("PHPT NUEVA ECIJA")){
            officeId = 18;
        }else if(office.equals("PHPT PAMPANGA")){
            officeId = 19;
        }else if(office.equals("PHPT ZAMBALES")){
            officeId = 20;
        }else if(office.equals("PHPT LAGUNA")){
            officeId = 21;
        }else if(office.equals("PHPT BATANGAS")){
            officeId = 22;
        }else if(office.equals("PHPT CAVITE")){
            officeId = 23;
        }else if(office.equals("PHPT RIZAL")){
            officeId = 24;
        }else if(office.equals("PHPT QUEZON")){
            officeId = 25;
        }else if(office.equals("PHPT MINDORO OCC")){
            officeId = 26;
        }else if(office.equals("PHPT PALAWAN")){
            officeId = 27;
        }else if(office.equals("PHPT MINDORO OR")){
            officeId = 28;
        }else if(office.equals("PHPT MARINDUQUE")){
            officeId = 29;
        }else if(office.equals("PHPT ROMBLON")){
            officeId = 30;
        }else if(office.equals("PHPT CAM NORTE")){
            officeId = 31;
        }else if(office.equals("PHPT CAM SUR")){
            officeId = 32;
        }else if(office.equals("PHPT ALBAY")){
            officeId = 33;
        }else if(office.equals("PHPT SORSOGON")){
            officeId = 34;
        }else if(office.equals("PHPT MASBATE")){
            officeId = 35;
        }else if(office.equals("PHPT CATANDUANES")){
            officeId = 36;
        }else if(office.equals("PHPT ILOILO")){
            officeId = 37;
        }else if(office.equals("PHPT AKLAN")){
            officeId = 38;
        }else if(office.equals("PHPT ANTIQUE")){
            officeId = 39;
        }else if(office.equals("PHPT CAPIZ")){
            officeId = 40;
        }else if(office.equals("PHPT GUIMARAS")){
            officeId = 41;
        }else if(office.equals("PHPT NEGROS OCC")){
            officeId = 42;
        }else if(office.equals("PHPT CEBU")){
            officeId = 43;
        }else if(office.equals("PHPT BOHOL")){
            officeId = 44;
        }else if(office.equals("PHPT NEGROS ORR")){
            officeId = 45;
        }else if(office.equals("PHPT METRO CEBU")){
            officeId = 46;
        }else if(office.equals("PHPT LEYTE NORTE")){
            officeId = 47;
        }else if(office.equals("PHPT LEYTE SUR")){
            officeId = 48;
        }else if(office.equals("PHPT WESTERN SAMAR")){
            officeId = 49;
        }else if(office.equals("PHPT NORTHERN SAMAR")){
            officeId = 50;
        }else if(office.equals("PHPT EASTERN SAMAR")){
            officeId = 51;
        }else if(office.equals("PHPT ZAMB DELSUR")){
            officeId = 52;
        }else if(office.equals("PHPT ZAMB NORTE")){
            officeId = 53;
        }else if(office.equals("PHPT ZAMB SIBUGAY")){
            officeId = 54;
        }else if(office.equals("PHPT CAGAYAN DE ORO")){
            officeId = 55;
        }else if(office.equals("PHPT ILIGAN CITY")){
            officeId = 56;
        }else if(office.equals("PHPT LANAO DEL NORTE")){
            officeId = 57;
        }else if(office.equals("PHPT BUKIDNON")){
            officeId = 58;
        }else if(office.equals("PHPT MISAMIS ORR")){
            officeId = 59;
        }else if(office.equals("PHPT MISAMIS OCC")){
            officeId = 60;
        }else if(office.equals("PHPT DAVAO DEL SUR")){
            officeId = 61;
        }else if(office.equals("PHPT DAVAO ORIENTAL")){
            officeId = 62;
        }else if(office.equals("PHPT DAVAO DEL NORTE")){
            officeId = 63;
        }else if(office.equals("PHPT COMPOSTELLA VALLEY")){
            officeId = 64;
        }else if(office.equals("PHPT GEN.SANTOS")){
            officeId = 65;
        }else if(office.equals("PHPT SULTAN KUDARAT")){
            officeId = 66;
        }else if(office.equals("PHPT SARANGANI")){
            officeId = 67;
        }else if(office.equals("PHPT SOUTH COTABATO")){
            officeId = 68;
        }else if(office.equals("PHPT NORTH COTABATO")){
            officeId = 69;
        }else if(office.equals("PHPT AGUSAN DEL NORTE")){
            officeId = 70;
        }else if(office.equals("PHPT AGUSAN DEL SUR")){
            officeId = 71;
        }else if(office.equals("PHPT SURIGAO DEL NORTE")){
            officeId = 72;
        }else if(office.equals("PHPT SURIGAO DEL SUR")){
            officeId = 73;
        }else if(office.equals("PHPT ABRA")){
            officeId = 74;
        }else if(office.equals("PHPT MT.PROVINCE")){
            officeId = 75;
        }else if(office.equals("PHPT IFUGAO")){
            officeId = 76;
        }else if(office.equals("PHPT KALINGA")){
            officeId = 77;
        }else if(office.equals("PHPT BENGUET")){
            officeId = 78;
        }else if(office.equals("PHPT LANAO DEL SUR")){
            officeId = 79;
        }else if(office.equals("PHPT MAGUINDANAO")){
            officeId = 80;
        }else if(office.equals("PHPT VASULTA")){
            officeId = 81;
        }

        if(formattedDate == null){
            Toast.makeText(getContext(),"Please Choose a Date",Toast.LENGTH_SHORT).show();
        }else if(time == null){
            Toast.makeText(getContext(),"Please Choose a Time",Toast.LENGTH_SHORT).show();
        }else {
            HashMap<String, String> params = new HashMap<>();
            params.put("datepicker", formattedDate);
            params.put("timepicker", timereserve);
            params.put("userId", String.valueOf(id));
            params.put("purpose", purpose);
            params.put("officeId", String.valueOf(officeId));
            params.put("regionId", String.valueOf(regionId));

            AddSchedule.PerformNetworkRequest request = new AddSchedule.PerformNetworkRequest(Links.ADD_SCHEDULE, params, CODE_POST_REQUEST);
            request.execute();
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        region = spnRegion.getSelectedItem().toString();
        List<String> list = new ArrayList<String>();

        if(region.contentEquals("RHPU NCR")) {
            list.add("Eastern District");
            list.add("Manila District");
            list.add("Northern District");
            list.add("QCHP District - La loma");
            list.add("QCHP District - Novaliches");
            list.add("Southern District - Muntinlupa");
            regionId = 1;
        }else if(region.contentEquals("RHPU 1")) {
            list.add("PHPT ILOCOS NORTE");
            list.add("PHPT ILOCOS SUR");
            list.add("PHPT LA UNION");
            list.add("PHPT PANGASINAN");
            regionId = 2;
        }else if(region.contentEquals("RHPU 2")) {
            list.add("PHPT CAGAYAN");
            list.add("PHPT ISABELA");
            list.add("PHPT NUEVA VISCAYA");
            list.add("PHPT QUIRINO");
            regionId = 3;
        }else if(region.contentEquals("RHPU 3")) {
            list.add("PHPT BATAAN");
            list.add("PHPT BULACAN");
            list.add("PHPT NUEVA ECIJA");
            list.add("PHPT PAMPANGA");
            list.add("PHPT TARLAC");
            list.add("PHPT ZAMBALES");
            regionId = 4;
        }else if(region.contentEquals("RHPU 4A")) {
            list.add("PHPT BATANGAS");
            list.add("PHPT CAVITE");
            list.add("PHPT LAGUNA");
            list.add("PHPT QUEZON");
            list.add("PHPT RIZAL");
            regionId = 5;
        }else if(region.contentEquals("RHPU 4B")) {
            list.add("PHPT MARINDUQUE");
            list.add("PHPT MINDORO OCC");
            list.add("PHPT MINDORO OR");
            list.add("PHPT PALAWAN");
            regionId = 6;
        }else if(region.contentEquals("RHPU 5")) {
            list.add("PHPT ALBAY");
            list.add("PHPT CAM NORTE");
            list.add("PHPT CAM SUR");
            list.add("PHPT CATANDUANES");
            list.add("PHPT MASBATE");
            list.add("PHPT SORSOGON");
            regionId = 7;
        }else if(region.contentEquals("RHPU 6")) {
            list.add("PHPT AKLAM");
            list.add("PHPT ANTIQUE");
            list.add("PHPT CAPIZ");
            list.add("PHPT GUIMARAS");
            list.add("PHPT ILOIOLO");
            list.add("PHPT NEGROS OCC");
            regionId = 8;
        }else if(region.contentEquals("RHPU 7")) {
            list.add("PHPT BOHOL");
            list.add("PHPT CEBU");
            list.add("PHPT METRO CEBU");
            list.add("PHPT NEGROS ORR");
            regionId = 9;
        }else if(region.contentEquals("RHPU 8")) {
            list.add("PHPT EASTERN SAMAR");
            list.add("PHPT LEYTE NORTE");
            list.add("PHPT LEYTE SUR");
            list.add("PHPT NORTHERN SAMAR");
            list.add("PHPT WESTERN SAMAR");
            regionId = 10;
        }else if(region.contentEquals("RHPU 9")) {
            list.add("PHPT ZAMB DELSUR");
            list.add("PHPT ZAMB NORTE");
            list.add("PHPT ZAMB SIBUGAY");
            regionId = 11;
        }else if(region.contentEquals("RHPU 10")) {
            list.add("PHPT BUKIDNON");
            list.add("PHPT CAGAYAN DE ORO");
            list.add("PHPT ILIGAN CITY");
            list.add("PHPT LANAO DEL NORTE");
            list.add("PHPT MISAMIS OCC");
            list.add("PHPT MISAMIS ORR");
            regionId = 12;
        }else if(region.contentEquals("RHPU 11")) {
            list.add("PHPT COMPOSTELLA VALLEY");
            list.add("PHPT DAVAO DEL NORTE");
            list.add("PHPT DAVAO DEL SUR");
            list.add("PHPT DAVAO ORIENTAL");
            regionId = 13;
        }else if(region.contentEquals("RHPU 12")) {
            list.add("PHPT GEN.SANTOS");
            list.add("PHPT NORTH COTABATO");
            list.add("PHPT SARANGANI");
            list.add("PHPT SOUTH COTABATO");
            list.add("PHPT SULTAN KUDARAT");
            regionId = 14;
        }else if(region.contentEquals("RHPU 13")) {
            list.add("PHPT AGUSAN DEL NORTE");
            list.add("PHPT AGUSAN DEL SUR");
            list.add("PHPT SURIGAO DEL SUR");
            list.add("PHPT SURIGAO DEL NORTE");
            regionId = 15;
        }else if(region.contentEquals("RHPU COR")) {
            list.add("PHPT ABRA");
            list.add("PHPT BENGUET");
            list.add("PHPT IFUAGAO");
            list.add("PHPT KALINGA");
            list.add("PHPT MT.PROVINCE");
            regionId = 16;
        }else if(region.contentEquals("ARMM")) {
            list.add("PHPT LANAO DEL SUR");
            list.add("PHPT MAGUINDANAO");
            list.add("PHPT VASULTA");
            regionId = 17;
        }

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dataAdapter.notifyDataSetChanged();
        spnOffice.setAdapter(dataAdapter);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    class PerformNetworkRequest extends AsyncTask<Void, Void, String> {

        //the url where we need to send the request
        String url;

        //the parameters
        HashMap<String, String> params;

        //the request code to define whether it is a GET or POST
        int requestCode;

        //constructor to initialize values
        PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }

        //when the task started displaying a progressbar
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Sending Report Please wait...");
            progressDialog.show();
            progressDialog.setCancelable(false);
        }


        //this method will give the response from the request
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            try {
                JSONObject object2 = new JSONObject(s);
                if (!object2.getBoolean("error2")) {
                    Toast.makeText(getContext(), object2.getString("message2") + " " +officeId, Toast.LENGTH_SHORT).show();
                    Fragment fragment = new Fragment_ViewSchedule();
                    FragmentManager fragmentManager = getFragmentManager();
                    FragmentTransaction ft = fragmentManager.beginTransaction();
                    ft.replace(R.id.screen_area,fragment);
                    ft.commit();
                }else{
                    Toast.makeText(getContext(), object2.getString("message2"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        //the network operation will be performed in background
        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler requestHandler = new RequestHandler();

            if (requestCode == CODE_POST_REQUEST)
                return requestHandler.sendPostRequest(url, params);
            return null;
        }
    }



    private void showDatePicker() {
        Fragment_DatePicker date = new Fragment_DatePicker();
        /**
         * Set Up Current Date Into dialog
         */
        Calendar calender = Calendar.getInstance();
        Bundle args = new Bundle();
        args.putInt("year", calender.get(Calendar.YEAR));
        args.putInt("month", calender.get(Calendar.MONTH));
        args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
        date.setArguments(args);
        /**
         * Set Call back to capture selected date
         */
        date.setCallBack(ondate);
        date.show(getFragmentManager(),"Date Picker");
    }

    DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {

        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {

            Calendar c = Calendar.getInstance();
            c.set(Calendar.YEAR,year);
            c.set(Calendar.MONTH,monthOfYear);
            c.set(Calendar.DAY_OF_MONTH,dayOfMonth);
            SimpleDateFormat df  = new SimpleDateFormat("yyyy-MM-dd");
            String formattedDate = df.format(c.getTime());
            txtDate.setText(formattedDate);
        }
    };
}
