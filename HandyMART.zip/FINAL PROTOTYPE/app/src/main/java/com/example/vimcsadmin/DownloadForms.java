package com.example.vimcsadmin;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Spinner;


public class DownloadForms extends Fragment {

    private  static final int PERMISSION_STORAGE_CODE = 1000;
    Spinner spnForms;
    Button btnDownload;
    String forms;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_download_forms, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        btnDownload = view.findViewById(R.id.btnDownload);
        spnForms = view.findViewById(R.id.spnForms);

        btnDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String url = "";
                forms = spnForms.getSelectedItem().toString();
                if(forms.equals("Request for Motor Vehicle Clearance Application")){
                    url = Links.DOWNLOAD_MOTOR_CLEARANCE;
                }else if(forms.equals("Request for Correction of Entry/Deletion")){
                    url = Links.DOWNLOAD_CORRECTION_OF_ENTRY_DELETION;
                }else if(forms.equals("Request for Nationwide Alarm")){
                    url = Links.DOWNLOAD_NATION_WIDE_ALARM;
                }else if(forms.equals("Request for Certificate of Non-Recovery")){
                    url = Links.DOWNLOAD_CERTIFICATE_OF_NON_RECOVERY;
                }else if(forms.equals("Request for Lifting of Alarm/Watch List")){
                    url = Links.DOWNLOAD_LIFTING_OF_ALARM;
                }else if(forms.equals("Request for Re-Stamping")){
                    url = Links.DOWNLOAD_RE_STAMPING;
                }

                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });
    }

}
