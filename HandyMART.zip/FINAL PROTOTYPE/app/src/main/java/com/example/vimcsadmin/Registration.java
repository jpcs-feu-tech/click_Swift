package com.example.vimcsadmin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;

public class Registration extends AppCompatActivity {

    EditText etPass, etCpass, etFname, etAddress, etLname, etUsername, etCity, etEmail;
    ImageView imgProfile;
    Button btnUpload,btnRegister,btnBack;
    ProgressDialog progressDialog;
    Uri imageUri;
    String encoded_string;
    private static final int CODE_POST_REQUEST = 1025;
    private static final int CHOOSE_IMAGE = 101;

    String username, pass, cpass, fname, lname, address, city, email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        etUsername = findViewById(R.id.etUser);
        etEmail = findViewById(R.id.etEmail);
        etPass = findViewById(R.id.etPass);
        etCpass = findViewById(R.id.etConfirmPass);
        etFname = findViewById(R.id.etFname);
        etLname = findViewById(R.id.etLname);
        etAddress = findViewById(R.id.etAddress);
        etCity = findViewById(R.id.etCity);
        imgProfile = findViewById(R.id.imgProfile);
        progressDialog = new ProgressDialog(this);
        btnRegister = findViewById(R.id.BtnRegister);
        btnUpload = findViewById(R.id.btnChoosePhoto);
        btnBack = findViewById(R.id.btnBack);


        btnUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showImageChooser();
                Toast.makeText(getApplicationContext(),encoded_string,Toast.LENGTH_SHORT).show();
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerProfile();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Login.class));
                finish();
            }
        });

    }

    private void registerProfile() {
        username = etUsername.getText().toString();
        pass = etPass.getText().toString();
        cpass = etPass.getText().toString();
        address = etAddress.getText().toString();
        city = etCity.getText().toString();
        email = etEmail.getText().toString();
        fname = etFname.getText().toString();
        lname = etLname.getText().toString();

        Toast.makeText(getApplicationContext(),username + " " + pass + " " + " " + email + " " + fname + lname + address + city, Toast.LENGTH_SHORT).show();

        if(username.isEmpty()){
            etUsername.setError("Please enter your Username");
            etUsername.requestFocus();
        }

        if(pass.isEmpty()){
            etPass.setError("Please enter your Password");
            etPass.requestFocus();
        }

        if(cpass.isEmpty()){
            etCpass.setError("Please enter your Confirm Password");
            etCpass.requestFocus();
        }

        if(!pass.equals(cpass)){
            etCpass.setError("Password Mismatch");
            etCpass.requestFocus();
        }

        if(address.isEmpty()){
            etAddress.setError("Please enter your address");
            etAddress.requestFocus();
        }

        if(city.isEmpty()){
            etCity.setError("Please enter your City");
            etCity.requestFocus();
        }

        if(fname.isEmpty()){
            etFname.setError("Please enter your Firstname");
        }

        if(lname.isEmpty()){
            etLname.setError("Please enter your Lastname");
            etLname.requestFocus();
        }

        if(encoded_string == null){
            Toast.makeText(getApplicationContext(),"Please Select a Photo", Toast.LENGTH_SHORT).show();
        }

        if(!username.isEmpty() && pass.equals(cpass) && !fname.isEmpty() && !lname.isEmpty() && !address.isEmpty() && !city.isEmpty() && !(encoded_string == null)){
            HashMap<String, String> params = new HashMap<>();
            params.put("fname", fname);
            params.put("lname", lname);
            params.put("username", username);
            params.put("address", address);
            params.put("password", pass);
            params.put("city", city);
            params.put("email",email);
            params.put("image", encoded_string);

            Registration.PerformNetworkRequest request = new Registration.PerformNetworkRequest(Links.REGISTER, params, CODE_POST_REQUEST);
            request.execute();
        }
    }

    class PerformNetworkRequest extends AsyncTask<Void, Void, String> {

        //the url where we need to send the request
        String url;

        //the parameters
        HashMap<String, String> params;

        //the request code to define whether it is a GET or POST
        int requestCode;

        //constructor to initialize values
        PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }

        //when the task started displaying a progressbar
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Registering Account Please wait...");
            progressDialog.show();
        }


        //this method will give the response from the request
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            Log.e("LOOK", s);
            try {
                JSONObject object2 = new JSONObject(s);
                if (!object2.getBoolean("error2")) {
                    Toast.makeText(getApplicationContext(), object2.getString("message2"), Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(),Login.class));
                    finish();
                }else{
                    Toast.makeText(getApplicationContext(), object2.getString("message2"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        //the network operation will be performed in background
        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler requestHandler = new RequestHandler();

            if (requestCode == CODE_POST_REQUEST)
                return requestHandler.sendPostRequest(url, params);
            return null;
        }
    }

    private void showImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"Select Profile Picture"), CHOOSE_IMAGE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == CHOOSE_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null){
            imageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),imageUri);
                int nh = (int) ( bitmap.getHeight() * (720.0 / bitmap.getWidth()) );
                Bitmap scaled = Bitmap.createScaledBitmap(bitmap, 720, nh, true);
                encoded_string = encodeTobase64(scaled);
                imgProfile.setImageBitmap(scaled);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    public static String encodeTobase64(Bitmap image) {
        Bitmap immagex=image;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        immagex.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] b = baos.toByteArray();
        String imageEncoded = Base64.encodeToString(b,Base64.DEFAULT);
        Log.e("LOOK", imageEncoded);
        return imageEncoded;
    }
}
