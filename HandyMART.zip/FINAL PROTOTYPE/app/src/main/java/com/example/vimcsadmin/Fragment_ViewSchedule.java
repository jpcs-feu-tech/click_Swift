package com.example.vimcsadmin;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;

public class Fragment_ViewSchedule extends Fragment {

    ListView emailListView;
    List<Schedule> emailList;
    ProgressDialog progressDialog;
    int id;
    private static final int CODE_POST_REQUEST = 1025;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fragment__view_schedule,null);
        progressDialog = new ProgressDialog(getContext());
        SharedPreferences sp = getActivity().getApplication().getSharedPreferences("user", MODE_PRIVATE);
        if(sp.contains("logStatus")) {
            id = sp.getInt("user_id", 0);
        }
        loadEmail();
        return view;
    }

    private void loadEmail() {
        HashMap<String, String> params = new HashMap<>();
        params.put("user_id", String.valueOf(id));
        Fragment_ViewSchedule.PerformNetworkRequest request = new Fragment_ViewSchedule.PerformNetworkRequest(Links.GET_RECORD, params, CODE_POST_REQUEST);
        request.execute();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        emailListView = view.findViewById(R.id.listviewTask);
        emailList = new ArrayList<>();

        emailListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final Schedule schedule = emailList.get(position);
                SharedPreferences sp = getActivity().getApplication().getSharedPreferences("schedule", MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.clear();
                editor.putString("purpose", schedule.getPurpose());
                editor.putString("date", schedule.getDate());
                editor.putString("time", schedule.getTime());
                editor.putString("dateAdded", schedule.getDateAdded());
                editor.putString("queue", schedule.getQueueNo());
                editor.putInt("officeId", schedule.getOffice());
                editor.putInt("regionId", schedule.getRegion());
                editor.commit();


                Fragment_DisplaySchedule fragment = new Fragment_DisplaySchedule();
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction ft = fragmentManager.beginTransaction();
                ft.replace(R.id.screen_area, fragment);
                ft.commit();
            }
        });

    }

    class EmailAdapter extends ArrayAdapter<Schedule>{

        List<Schedule> emailList;

        public EmailAdapter(List<Schedule> emailList){
            super(getActivity().getApplicationContext(),R.layout.task_layout_list,emailList);
            this.emailList = emailList;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View emailListView = inflater.inflate(R.layout.task_layout_list, null, true);

            TextView txtSenderName = emailListView.findViewById(R.id.txtTask);
            TextView txtDateTime = emailListView.findViewById(R.id.txtDateTime);


            final Schedule email = emailList.get(position);

            txtSenderName.setText("Purpose: "+ email.getPurpose());
            txtDateTime.setText("Date and Time Schedule: "+ email.getTime() + " " + email.getDate());

            return emailListView;
        }
    }

    private class PerformNetworkRequest extends AsyncTask<Void, Void, String> {

        //the url where we need to send the request
        String url;

        //the parameters
        HashMap<String, String> params;

        //the request code to define whether it is a GET or POST
        int requestCode;

        //constructor to initialize values
        PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }

        //when the task started displaying a progressbar
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Loading Schedules Please wait...");
            progressDialog.show();
        }


        //this method will give the response from the request
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (!object.getBoolean("error2")) {
                    loadReportList(object.getJSONArray("schedule"));
                    Toast.makeText(getActivity().getApplicationContext(), object.getString("message2"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        //the network operation will be performed in background
        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler requestHandler = new RequestHandler();

            if (requestCode == CODE_POST_REQUEST)
                return requestHandler.sendPostRequest(url, params);

            return null;
        }
    }

    private void loadReportList(JSONArray emails) throws JSONException {
        //clearing previous heroes
        emailList.clear();

        for (int i = emails.length()-1; i >= 0; i--) {
            //getting each object
            JSONObject obj = emails.getJSONObject(i);

            emailList.add(new Schedule(
                    obj.getInt("id"),
                    obj.getInt("userId"),
                    obj.getString("purpose"),
                    obj.getString("scheduledDate"),
                    obj.getString("scheduledTime"),
                    obj.getString("dateAdded"),
                    obj.getString("queueNo"),
                    obj.getInt("regionId"),
                    obj.getInt("officeId")
            ));
        }

        EmailAdapter adapter = new EmailAdapter(emailList);
        emailListView.setAdapter(adapter);
    }

}

