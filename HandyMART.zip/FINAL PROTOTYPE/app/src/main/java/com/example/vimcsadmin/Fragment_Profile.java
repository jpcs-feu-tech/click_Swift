package com.example.vimcsadmin;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;


public class Fragment_Profile extends Fragment {


    ImageView imgPic;
    TextView txtName, txtEmail, txtAddress, txtCity;
    String fname, lname,email, address,city,photo= "";
    String imgUrl;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        SharedPreferences sp = getActivity().getApplication().getSharedPreferences("user", Context.MODE_PRIVATE);
        if(sp.contains("logStatus")) {
            fname = sp.getString("fname",null);
            lname = sp.getString("lname",null);
            email = sp.getString("email",null);
            photo = sp.getString("photo",null);
            address = sp.getString("address",null);
            city = sp.getString("city",null);
        }
        return inflater.inflate(R.layout.fragment_fragment__profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        imgUrl = Links.ROOT_URL + "assets/img/participants/" + photo;
        txtName = view.findViewById(R.id.txtName);
        txtEmail = view.findViewById(R.id.txtEmail);
        txtAddress = view.findViewById(R.id.txtAddress);
        txtCity = view.findViewById(R.id.txtCity);
        imgPic = view.findViewById(R.id.imgPic);

        txtName.setText(fname + " " + lname);
        txtEmail.setText(email);
        txtAddress.setText(address);
        txtCity.setText(city);

        if(photo != null){
            Picasso.get().load(imgUrl).placeholder(R.drawable.ic_launcher_foreground).into(imgPic);
        }

    }
}
