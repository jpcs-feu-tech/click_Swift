package com.example.vimcsadmin;

public class Status {

    String engNo, chasisNo, plateNo ;
    int id,applicationStatus, stampingStatus, correctionStatus;

    public Status(String engNo, String chasisNo, String plateNo, int applicationStatus, int stampingStatus, int correctionStatus, int id) {
        this.engNo = engNo;
        this.chasisNo = chasisNo;
        this.plateNo = plateNo;
        this.applicationStatus = applicationStatus;
        this.stampingStatus = stampingStatus;
        this.correctionStatus = correctionStatus;
        this.id = id;
    }

    public String getEngNo() {
        return engNo;
    }

    public void setEngNo(String engNo) {
        this.engNo = engNo;
    }

    public String getChasisNo() {
        return chasisNo;
    }

    public void setChasisNo(String chasisNo) {
        this.chasisNo = chasisNo;
    }

    public String getPlateNo() {
        return plateNo;
    }

    public void setPlateNo(String plateNo) {
        this.plateNo = plateNo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(int applicationStatus) {
        this.applicationStatus = applicationStatus;
    }

    public int getStampingStatus() {
        return stampingStatus;
    }

    public void setStampingStatus(int stampingStatus) {
        this.stampingStatus = stampingStatus;
    }

    public int getCorrectionStatus() {
        return correctionStatus;
    }

    public void setCorrectionStatus(int correctionStatus) {
        this.correctionStatus = correctionStatus;
    }


}
