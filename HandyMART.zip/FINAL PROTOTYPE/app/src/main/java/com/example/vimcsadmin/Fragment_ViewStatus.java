package com.example.vimcsadmin;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;

public class Fragment_ViewStatus extends Fragment {
    ListView emailListView;
    List<Status> emailList;
    ProgressDialog progressDialog;
    String email;
    private static final int CODE_POST_REQUEST = 1025;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fragment__view_schedule,null);
        progressDialog = new ProgressDialog(getContext());
        SharedPreferences sp = getActivity().getApplication().getSharedPreferences("user", MODE_PRIVATE);
        if(sp.contains("logStatus")) {
            email = sp.getString("email", null);
        }
        loadEmail();
        return view;
    }

    private void loadEmail() {
        HashMap<String, String> params = new HashMap<>();
        params.put("email", email);
        Fragment_ViewStatus.PerformNetworkRequest request = new Fragment_ViewStatus.PerformNetworkRequest(Links.GET_STATUS, params, CODE_POST_REQUEST);
        request.execute();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        emailListView = view.findViewById(R.id.listviewTask);
        emailList = new ArrayList<>();

        emailListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final Status status = emailList.get(position);
                SharedPreferences sp = getActivity().getApplication().getSharedPreferences("status", MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.clear();
                editor.putString("engNo", status.getEngNo());
                editor.putString("chassisNo", status.getChasisNo());
                editor.putString("plateNo", status.getPlateNo());
                editor.putInt("applicationStatus", status.getApplicationStatus());
                editor.putInt("stampingStatus", status.getStampingStatus());
                editor.putInt("correctionStatus", status.getCorrectionStatus());
                editor.commit();


                Fragment_DisplayStatus fragment = new Fragment_DisplayStatus();
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction ft = fragmentManager.beginTransaction();
                ft.replace(R.id.screen_area, fragment);
                ft.commit();
            }
        });

    }

    class EmailAdapter extends ArrayAdapter<Status> {

        List<Status> emailList;

        public EmailAdapter(List<Status> emailList){
            super(getActivity().getApplicationContext(),R.layout.task_layout_list,emailList);
            this.emailList = emailList;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View emailListView = inflater.inflate(R.layout.status_layout_list, null, true);

            TextView txtPlateNo = emailListView.findViewById(R.id.txtPlateNo);
            TextView txtEngineNo = emailListView.findViewById(R.id.txtEngineNo);
            TextView txtChasisNo = emailListView.findViewById(R.id.txtChasisNo);


            final Status status = emailList.get(position);

            txtPlateNo.setText(status.getPlateNo());
            txtEngineNo.setText(status.getEngNo());
            txtChasisNo.setText(status.getEngNo());

            return emailListView;
        }
    }

    private class PerformNetworkRequest extends AsyncTask<Void, Void, String> {

        //the url where we need to send the request
        String url;

        //the parameters
        HashMap<String, String> params;

        //the request code to define whether it is a GET or POST
        int requestCode;

        //constructor to initialize values
        PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }

        //when the task started displaying a progressbar
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Loading Mails Please wait...");
            progressDialog.show();
        }


        //this method will give the response from the request
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (!object.getBoolean("error2")) {
                    loadReportList(object.getJSONArray("status"));
                    Toast.makeText(getActivity().getApplicationContext(), object.getString("message2"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        //the network operation will be performed in background
        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler requestHandler = new RequestHandler();

            if (requestCode == CODE_POST_REQUEST)
                return requestHandler.sendPostRequest(url, params);

            return null;
        }
    }

    private void loadReportList(JSONArray emails) throws JSONException {
        //clearing previous heroes
        emailList.clear();

        for (int i = emails.length()-1; i >= 0; i--) {
            //getting each object
            JSONObject obj = emails.getJSONObject(i);

            emailList.add(new Status(
                    obj.getString("engineNumber"),
                    obj.getString("chassisNumber"),
                    obj.getString("plateNo"),
                    obj.getInt("clearanceStatus"),
                    obj.getInt("stampingStatus"),
                    obj.getInt("correctionStatus"),
                    obj.getInt("id")
            ));
        }

        Fragment_ViewStatus.EmailAdapter adapter = new Fragment_ViewStatus.EmailAdapter(emailList);
        emailListView.setAdapter(adapter);
    }
}
